const MAX_ITEMS = 100;

const FA_LIST = [
  { id:'fa-user',      cls:'fa-solid fa-user' },
  { id:'fa-envelope',  cls:'fa-solid fa-envelope' },
  { id:'fa-house',     cls:'fa-solid fa-house' },
  { id:'fa-phone',     cls:'fa-solid fa-phone' },
  { id:'fa-marker',    cls:'fa-solid fa-marker' },
  { id:'fa-link',      cls:'fa-solid fa-link' },
  { id:'fa-star',      cls:'fa-solid fa-star' },
  { id:'fa-tag',       cls:'fa-solid fa-tag' },
  { id:'fa-calendar',  cls:'fa-solid fa-calendar' },
  { id:'fa-briefcase', cls:'fa-solid fa-briefcase' },
];
const FA_COLORS = [
  '#E6F1FB:#185FA5','#EEEDFE:#534AB7','#E1F5EE:#0F6E56','#FAECE7:#993C1D',
  '#FAEEDA:#854F0B','#EAF3DE:#3B6D11','#FBEAF0:#993556','#FCEBEB:#A32D2D',
  '#E6F5FB:#0D6E8F','#F0EFE6:#5C5630',
];
const PASTEL = ['#FFB3C6','#FFDEA8','#C3F0A2','#A8DFFE','#D4B8F0','#FFE0A8','#B8F0E6','#D3D3E8','#F7C8A8'];
const DEFAULT_ICON = { type:'color', id:'fa-user' };

const SAMPLE_ITEMS = [
  {id:1,value:'山田 太郎',                group:'基本情報',  icon:{type:'color',id:'fa-user'}},
  {id:2,value:'taro.yamada@example.com',  group:'基本情報',  icon:{type:'color',id:'fa-envelope'}},
  {id:3,value:'090-1234-5678',            group:'基本情報',  icon:{type:'color',id:'fa-phone'}},
  {id:4,value:'山田商店',                 group:'ビジネス',  icon:{type:'color',id:'fa-marker'}},
  {id:5,value:'長野県長野市◯◯町1-2-3',  group:'ビジネス',  icon:{type:'color',id:'fa-house'}},
  {id:6,value:'https://yamada-shoten.example.com', group:'ビジネス', icon:{type:'color',id:'fa-link'}},
  {id:7,value:'手作りジャムと地元野菜の出展を毎年行っています。お気軽にお声がけください！', group:'テンプレート', icon:{type:'dot',id:'dot-0'}},
];
const SAMPLE_GROUPS = ['基本情報','ビジネス','テンプレート'];

const t = key => chrome.i18n.getMessage(key) || key;

let items=[], groups=[], activeGroup='';
let editingId=null, nextId=1, dragSrcIdx=null;
let openPickerId=null;
let formIcon = {...DEFAULT_ICON};
let leftyMode = false;

// ── Storage ───────────────────────────────────────────────────
function save(){ chrome.storage.local.set({pb_items:items, pb_groups:groups, pb_lefty:leftyMode}); }
function load(cb){
  chrome.storage.local.get(['pb_items','pb_groups','pb_initialized','pb_lefty'], r=>{
    leftyMode = !!r.pb_lefty;
    document.body.classList.toggle('lefty', leftyMode);
    if(r.pb_items && r.pb_items.length){ items=r.pb_items; }
    else if(!r.pb_initialized){
      items=SAMPLE_ITEMS; groups=SAMPLE_GROUPS;
      chrome.storage.local.set({pb_items:items,pb_groups:groups,pb_initialized:true});
    }
    if(r.pb_groups && r.pb_groups.length) groups=r.pb_groups;
    nextId=items.length?Math.max(...items.map(i=>i.id))+1:1;
    activeGroup=t('groupAll');
    cb();
  });
}

// ── View ──────────────────────────────────────────────────────
function showView(id){
  ['viewMain','viewForm','viewStyle'].forEach(v=>{
    document.getElementById(v).style.display=v===id?'block':'none';
  });
  document.body.style.height=(id!=='viewMain')?'540px':'';
  document.body.style.overflowY=(id!=='viewMain')?'auto':'';
  closePicker();
}

// ── Icon helpers ──────────────────────────────────────────────
function getIconStyle(icon){
  const ic=icon||DEFAULT_ICON;
  if(ic.type==='dot'){
    const idx=parseInt(ic.id.split('-')[1])||0;
    return {bg:'transparent',tx:null,cls:null,dotColor:PASTEL[idx]};
  }
  const faIdx=FA_LIST.findIndex(f=>f.id===ic.id);
  const i=faIdx>=0?faIdx:0;
  const [bg,tx]=FA_COLORS[i].split(':');
  const cls=FA_LIST[i].cls;
  if(ic.type==='mono') return {bg:'transparent',tx:'#1a1a1a',cls,dotColor:null};
  return {bg,tx,cls,dotColor:null};
}
function renderIconEl(icon){
  const s=getIconStyle(icon);
  if(s.dotColor) return `<svg width="22" height="22" viewBox="0 0 22 22"><circle cx="11" cy="11" r="9" fill="${s.dotColor}"/></svg>`;
  return `<i class="${s.cls}" style="font-size:15px;color:${s.tx};"></i>`;
}

// ── Inline picker (メイン画面) ────────────────────────────────
function buildPickerHTML(currentIcon){
  const ic=currentIcon||DEFAULT_ICON;
  const colorOpts=FA_LIST.map((f,i)=>{
    const [bg,tx]=FA_COLORS[i].split(':');
    const sel=ic.type==='color'&&ic.id===f.id?' selected':'';
    return `<div class="picker-opt${sel}" style="background:${bg};" data-type="color" data-id="${f.id}"><i class="${f.cls}" style="font-size:13px;color:${tx};"></i></div>`;
  }).join('');
  const monoOpts=FA_LIST.map(f=>{
    const sel=ic.type==='mono'&&ic.id===f.id?' selected':'';
    return `<div class="picker-opt${sel}" style="background:#f5f5f5;" data-type="mono" data-id="${f.id}"><i class="${f.cls}" style="font-size:13px;color:#1a1a1a;"></i></div>`;
  }).join('');
  const dotOpts=PASTEL.map((c,i)=>{
    const sel=ic.type==='dot'&&ic.id===`dot-${i}`?' selected':'';
    return `<div class="picker-opt${sel}" data-type="dot" data-id="dot-${i}"><svg width="18" height="18" viewBox="0 0 18 18"><circle cx="9" cy="9" r="7" fill="${c}"/></svg></div>`;
  }).join('');
  return `<div class="picker-section"><div class="picker-row">${colorOpts}</div></div>
    <div class="picker-divider"></div>
    <div class="picker-section"><div class="picker-row">${monoOpts}</div></div>
    <div class="picker-divider"></div>
    <div class="picker-section"><div class="picker-row">${dotOpts}</div></div>`;
}
function openPicker(itemId){
  if(openPickerId===itemId){closePicker();return;}
  closePicker();
  openPickerId=itemId;
  const el=document.getElementById(`picker-${itemId}`);
  if(!el)return;
  const item=items.find(i=>i.id===itemId);
  el.innerHTML=buildPickerHTML(item?.icon);
  el.classList.add('open');
  el.querySelectorAll('.picker-opt').forEach(opt=>{
    opt.addEventListener('click',e=>{
      e.stopPropagation();
      items=items.map(i=>i.id===itemId?{...i,icon:{type:opt.dataset.type,id:opt.dataset.id}}:i);
      save();closePicker();render();
    });
  });
}
function closePicker(){
  if(openPickerId!==null){
    const el=document.getElementById(`picker-${openPickerId}`);
    if(el)el.classList.remove('open');
    openPickerId=null;
  }
}

// ── Icon grid (フォーム内) ─────────────────────────────────────
function buildIconGrid(currentIcon){
  const ic=currentIcon||DEFAULT_ICON;
  const colorOpts=FA_LIST.map((f,i)=>{
    const [bg,tx]=FA_COLORS[i].split(':');
    const sel=ic.type==='color'&&ic.id===f.id?' selected':'';
    return `<div class="icon-grid-opt${sel}" style="background:${bg};" data-type="color" data-id="${f.id}"><i class="${f.cls}" style="font-size:15px;color:${tx};"></i></div>`;
  }).join('');
  const monoOpts=FA_LIST.map(f=>{
    const sel=ic.type==='mono'&&ic.id===f.id?' selected':'';
    return `<div class="icon-grid-opt${sel}" style="background:#f0f0f0;" data-type="mono" data-id="${f.id}"><i class="${f.cls}" style="font-size:15px;color:#1a1a1a;"></i></div>`;
  }).join('');
  const dotOpts=PASTEL.map((c,i)=>{
    const sel=ic.type==='dot'&&ic.id===`dot-${i}`?' selected':'';
    return `<div class="icon-grid-opt${sel}" data-type="dot" data-id="dot-${i}"><svg width="22" height="22" viewBox="0 0 22 22"><circle cx="11" cy="11" r="9" fill="${c}"/></svg></div>`;
  }).join('');
  return `
    <div class="icon-grid-section"><div class="icon-grid-row">${colorOpts}</div></div>
    <div class="icon-grid-divider"></div>
    <div class="icon-grid-section"><div class="icon-grid-row">${monoOpts}</div></div>
    <div class="icon-grid-divider"></div>
    <div class="icon-grid-section"><div class="icon-grid-row">${dotOpts}</div></div>`;
}
function renderIconGrid(currentIcon){
  const grid=document.getElementById('iconGrid');
  grid.innerHTML=buildIconGrid(currentIcon);
  grid.querySelectorAll('.icon-grid-opt').forEach(opt=>{
    opt.addEventListener('click',()=>{
      formIcon={type:opt.dataset.type,id:opt.dataset.id};
      grid.querySelectorAll('.icon-grid-opt').forEach(o=>o.classList.remove('selected'));
      opt.classList.add('selected');
    });
  });
}

// ── Render ────────────────────────────────────────────────────
function filteredItems(){ return activeGroup===t('groupAll')?[...items]:items.filter(i=>i.group===activeGroup); }

function updateItemCount(){
  document.getElementById('itemCount').textContent=`${items.length} / ${MAX_ITEMS}`;
  const warn=document.getElementById('limitWarn');
  const addBtn=document.getElementById('btnAddItem');
  if(items.length>=MAX_ITEMS){
    warn.style.display='block';
    warn.textContent=t('limitReached')||`上限 ${MAX_ITEMS} 件に達しました`;
    addBtn.disabled=true; addBtn.style.opacity='0.4'; addBtn.style.cursor='not-allowed';
  } else {
    warn.style.display='none';
    addBtn.disabled=false; addBtn.style.opacity=''; addBtn.style.cursor='';
  }
}

function render(){
  const gc=document.getElementById('groupChips');
  const allLabel=t('groupAll');
  gc.innerHTML=[allLabel,...groups].map(g=>
    `<button class="group-chip${g===activeGroup?' active':''}" data-group="${g}">${g}</button>`
  ).join('')+`<button class="add-group-btn" id="btnOpenStyleFromGroup">${t('btnAddGroup')}</button>`;
  gc.querySelectorAll('.group-chip').forEach(b=>b.addEventListener('click',()=>{activeGroup=b.dataset.group;render();}));
  const agb=document.getElementById('btnOpenStyleFromGroup');
  if(agb)agb.addEventListener('click',openStyleView);

  updateItemCount();

  const fi=filteredItems();
  const list=document.getElementById('itemList');
  if(!fi.length){list.innerHTML='';document.getElementById('emptyState').style.display='block';return;}
  document.getElementById('emptyState').style.display='none';

  let html='';
  fi.forEach((item,i)=>{
    const s=getIconStyle(item.icon);
    const iconInner=renderIconEl(item.icon);
    html+=`<div class="insert-zone" data-iz="${i}"></div>`;
    html+=`<div class="item" draggable="true" data-id="${item.id}" data-idx="${i}">
      <span class="drag-handle">&#8942;&#8942;</span>
      <div class="item-icon-btn" data-pickfor="${item.id}" style="background:${s.dotColor?'transparent':s.bg};" title="アイコンを変更">
        ${iconInner}
        <div class="icon-picker" id="picker-${item.id}"></div>
      </div>
      <div class="item-body">
        <div class="item-value">${item.value}</div>
        ${item.group?`<div class="item-group">${item.group}</div>`:''}
      </div>
      <div class="item-actions">
        <button class="edit-btn" data-edit="${item.id}">${t('editItem')}</button>
        <button class="copy-btn" data-copy="${item.id}">${t('btnCopy')}</button>
      </div>
    </div>`;
  });
  html+=`<div class="insert-zone" data-iz="${fi.length}"></div>`;
  list.innerHTML=html;

  list.querySelectorAll('[data-pickfor]').forEach(btn=>{
    btn.addEventListener('click',e=>{e.stopPropagation();openPicker(+btn.dataset.pickfor);});
  });
  list.querySelectorAll('[data-edit]').forEach(b=>b.addEventListener('click',()=>openEdit(+b.dataset.edit)));
  list.querySelectorAll('[data-copy]').forEach(b=>b.addEventListener('click',()=>copyItem(+b.dataset.copy,b)));
  list.querySelectorAll('.item[draggable]').forEach(el=>{
    const idx=+el.dataset.idx;
    el.addEventListener('dragstart',e=>dStart(e,idx));
    el.addEventListener('dragend',dEnd);
  });
  list.querySelectorAll('.insert-zone').forEach(el=>{
    const iz=+el.dataset.iz;
    el.addEventListener('dragover',e=>izOver(e,iz));
    el.addEventListener('dragleave',()=>izLeave(iz));
    el.addEventListener('drop',e=>izDrop(e,iz));
  });
}

// ── Drag ──────────────────────────────────────────────────────
function dStart(e,idx){dragSrcIdx=idx;setTimeout(()=>{const el=document.querySelector(`.item[data-idx="${idx}"]`);if(el)el.classList.add('dragging');},0);}
function dEnd(){dragSrcIdx=null;document.querySelectorAll('.item').forEach(el=>el.classList.remove('dragging'));document.querySelectorAll('.insert-zone').forEach(z=>z.classList.remove('drag-target'));}
function izOver(e,i){e.preventDefault();document.querySelectorAll('.insert-zone').forEach(z=>z.classList.remove('drag-target'));const z=document.querySelector(`.insert-zone[data-iz="${i}"]`);if(z)z.classList.add('drag-target');}
function izLeave(i){const z=document.querySelector(`.insert-zone[data-iz="${i}"]`);if(z)z.classList.remove('drag-target');}
function izDrop(e,insertIdx){
  e.preventDefault();if(dragSrcIdx===null)return;
  const fi=filteredItems();const srcItem=fi[dragSrcIdx];if(!srcItem)return;
  const srcGlobalIdx=items.findIndex(i=>i.id===srcItem.id);items.splice(srcGlobalIdx,1);
  let tgt;
  if(insertIdx>=fi.length)tgt=items.length;
  else{const ti=fi[insertIdx>dragSrcIdx?insertIdx-1:insertIdx];tgt=ti?items.findIndex(i=>i.id===ti.id)+(insertIdx>dragSrcIdx?1:0):items.length;}
  items.splice(Math.max(0,Math.min(tgt,items.length)),0,srcItem);
  dEnd();render();save();
}

// ── Copy ──────────────────────────────────────────────────────
function copyItem(id,btn){
  const item=items.find(i=>i.id===id);if(!item)return;
  const done=()=>{btn.textContent=t('btnCopied');btn.classList.add('copied');showToast(t('toastCopied'));setTimeout(()=>{btn.textContent=t('btnCopy');btn.classList.remove('copied');},2000);};
  navigator.clipboard.writeText(item.value).then(done).catch(()=>{const ta=document.createElement('textarea');ta.value=item.value;ta.style.cssText='position:fixed;opacity:0';document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);done();});
}
function showToast(msg){const t2=document.getElementById('toast');t2.textContent=msg;t2.classList.add('show');setTimeout(()=>t2.classList.remove('show'),2200);}

// ── Form ──────────────────────────────────────────────────────
function buildGroupSelect(sel){
  const s=document.getElementById('inputGroup');
  s.innerHTML=`<option value="">${t('optionNone')}</option>`+groups.map(g=>`<option value="${g}"${g===sel?' selected':''}>${g}</option>`).join('');
}
function openModal(){
  if(items.length>=MAX_ITEMS)return;
  editingId=null;
  formIcon={...DEFAULT_ICON};
  document.getElementById('formTitle').textContent=t('addItem');
  document.getElementById('inputValue').value='';
  document.getElementById('btnDelItem').style.display='none';
  buildGroupSelect(activeGroup!==t('groupAll')?activeGroup:'');
  renderIconGrid(formIcon);
  showView('viewForm');
  setTimeout(()=>document.getElementById('inputValue').focus(),50);
}
function openEdit(id){
  const item=items.find(i=>i.id===id);if(!item)return;
  editingId=id;
  formIcon={...(item.icon||DEFAULT_ICON)};
  document.getElementById('formTitle').textContent=t('editItem');
  document.getElementById('inputValue').value=item.value;
  document.getElementById('btnDelItem').style.display='inline-block';
  buildGroupSelect(item.group||'');
  renderIconGrid(formIcon);
  showView('viewForm');
  setTimeout(()=>document.getElementById('inputValue').focus(),50);
}
function closeForm(){showView('viewMain');}
function saveItem(){
  const value=document.getElementById('inputValue').value.trim();
  const group=document.getElementById('inputGroup').value;
  if(!value)return;
  if(editingId) items=items.map(i=>i.id===editingId?{...i,value,group,icon:formIcon}:i);
  else {
    if(items.length>=MAX_ITEMS)return;
    items.push({id:nextId++,value,group,icon:formIcon});
  }
  closeForm();render();save();
}
function delCurrentItem(){
  if(!editingId||!confirm(t('confirmDelete')))return;
  items=items.filter(i=>i.id!==editingId);
  closeForm();render();save();
}

// ── Style / Group ─────────────────────────────────────────────
function openStyleView(){renderGroupTags();showView('viewStyle');}
function addGroup(){
  const inp=document.getElementById('newGroupInput');
  const name=inp.value.trim();
  if(!name||groups.includes(name))return;
  groups.push(name);inp.value='';
  renderGroupTags();render();save();
}
function removeGroup(g){
  if(!confirm(`"${g}" ${t('confirmDelGrp')}`))return;
  groups=groups.filter(x=>x!==g);
  items=items.map(i=>i.group===g?{...i,group:''}:i);
  if(activeGroup===g)activeGroup=t('groupAll');
  renderGroupTags();render();save();
}
function renameGroup(orig){
  const newName=prompt(t('promptRename')||'新しいグループ名を入力してください', orig);
  if(!newName||newName===orig)return;
  if(groups.includes(newName)){alert(t('errorGroupExists')||'同じ名前のグループがすでにあります');return;}
  groups=groups.map(g=>g===orig?newName:g);
  items=items.map(i=>i.group===orig?{...i,group:newName}:i);
  if(activeGroup===orig)activeGroup=newName;
  save();render();renderGroupTags();
}
function renderGroupTags(){
  const el=document.getElementById('groupTagList');
  if(!groups.length){
    el.innerHTML=`<div style="font-size:12px;color:#aaa;padding:4px 0;">${t('noGroups')||'グループがありません'}</div>`;
    return;
  }
  el.innerHTML=groups.map(g=>`
    <div class="group-row">
      <span class="group-row-name">${g}</span>
      <div class="group-row-actions">
        <button class="group-row-btn" data-edit="${g}">${t('btnEdit')||'編集'}</button>
        <button class="group-row-btn group-row-del" data-rm="${g}">${t('btnDelete')||'削除'}</button>
      </div>
    </div>`).join('');
  el.querySelectorAll('[data-edit]').forEach(b=>b.addEventListener('click',()=>renameGroup(b.dataset.edit)));
  el.querySelectorAll('[data-rm]').forEach(b=>b.addEventListener('click',()=>removeGroup(b.dataset.rm)));
}

// ── i18n labels ───────────────────────────────────────────────
function applyLabels(){
  document.getElementById('lblAdd').textContent       = t('btnAdd').replace('+ ','');
  document.getElementById('emptyState').textContent   = t('empty');
  document.getElementById('btnBack').textContent      = t('btnBack');
  document.getElementById('btnBackStyle').textContent = t('btnBack');
  document.getElementById('lblIconSelect').textContent= t('labelIconSelect')||'アイコンを選択';
  document.getElementById('lblContent').textContent   = t('labelContent');
  document.getElementById('lblGroupField').textContent= t('labelGroup');
  document.getElementById('btnDelItem').textContent   = t('btnDelete');
  document.getElementById('btnCancelItem').textContent= t('btnCancel');
  document.getElementById('btnSaveItem').textContent  = t('btnSave');
  document.getElementById('lblManageGroups').textContent=t('manageGroups');
  document.getElementById('newGroupInput').placeholder= t('newGroupPh');
  document.getElementById('btnAddGroup').textContent  = t('btnAddGroupBtn');
  document.getElementById('inputValue').placeholder   = t('valuePlaceholder');
  document.getElementById('lblStyleTitle').textContent = t('settingsTitle')||'設定';
  document.getElementById('lblLayoutTitle').textContent= t('layoutTitle')||'レイアウト';
  document.getElementById('lblLefty').textContent      = t('leftyLabel')||'左利きモード（ボタンを左側に）';
  document.getElementById('lblIOTitle').textContent   = t('ioTitle')||'データの管理';
  document.getElementById('btnExport').textContent    = t('btnExport')||'エクスポート';
  document.getElementById('btnImport').textContent    = t('btnImport')||'インポート';
}

// ── Export / Import ──────────────────────────────────────────
function exportData(){
  const data = JSON.stringify({version:'1.0.4', items, groups}, null, 2);
  const blob = new Blob([data], {type:'application/json'});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  const date = new Date().toISOString().slice(0,10);
  a.href     = url;
  a.download = `CopyStock_backup_${date}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast(t('toastExported')||'エクスポートしました');
}

function importData(file){
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      if(!data.items || !Array.isArray(data.items)) throw new Error('invalid');
      if(!confirm(t('confirmImport')||'現在のデータを上書きしてインポートしますか？')) return;
      items  = data.items;
      groups = data.groups && Array.isArray(data.groups) ? data.groups : [];
      nextId = items.length ? Math.max(...items.map(i=>i.id))+1 : 1;
      save();
      activeGroup = t('groupAll');
      showView('viewMain');
      render();
      showToast(t('toastImported')||'インポートしました');
    } catch(err){
      alert(t('errorImport')||'ファイルの読み込みに失敗しました');
    }
  };
  reader.readAsText(file);
}

// ── Init ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded',()=>{
  applyLabels();
  document.getElementById('btnAddItem').addEventListener('click',openModal);
  document.getElementById('btnOpenStyle').addEventListener('click',openStyleView);
  document.getElementById('btnSaveItem').addEventListener('click',saveItem);
  document.getElementById('btnCancelItem').addEventListener('click',closeForm);
  document.getElementById('btnBack').addEventListener('click',closeForm);
  document.getElementById('btnDelItem').addEventListener('click',delCurrentItem);
  document.getElementById('btnBackStyle').addEventListener('click',()=>showView('viewMain'));
  document.getElementById('btnAddGroup').addEventListener('click',addGroup);
  document.getElementById('newGroupInput').addEventListener('keydown',e=>{if(e.key==='Enter')addGroup();});
  document.addEventListener('click',()=>closePicker());
  document.getElementById('btnExport').addEventListener('click', exportData);
  document.getElementById('btnImport').addEventListener('click', ()=>document.getElementById('importFile').click());
  document.getElementById('importFile').addEventListener('change', e=>{ importData(e.target.files[0]); e.target.value=''; });
  const toggleLefty = document.getElementById('toggleLefty');
  toggleLefty.checked = leftyMode;
  toggleLefty.addEventListener('change',()=>{
    leftyMode = toggleLefty.checked;
    document.body.classList.toggle('lefty', leftyMode);
    save();
  });
  load(render);
});
